package photoAlbum;

import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AboutDialog extends JDialog {

	private static final long serialVersionUID = 1;
	private JLabel icon;
	private JLabel title;
	private JLabel author;
	private JLabel copyright;
	private JPanel grid;
	
	public AboutDialog(JFrame parent) {
		super(parent, "About this library ... ", true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		grid = new JPanel();
		grid.setLayout(new GridLayout(1,2));
		
		JPanel leftPanel = new JPanel();
		JPanel rightPanel = new JPanel(); 
		ImageIcon img = new ImageIcon("Photos//book.jpg");
		JLabel imgLabel = new JLabel(img);
		leftPanel.add(imgLabel);
		grid.add(leftPanel);
		grid.add(rightPanel);
		add(grid);
		
		setResizable(false);
		pack();
		setLocationRelativeTo(parent);
		setVisible(true);
	}
	
}
